<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>SMTP Testing</title>
  </head>
  <body>
  <?php
include('smtp/PHPMailerAutoload.php');
$myemailIds = array (
  array("ikftest33@gmail.com",'ikf@123$$1',587,"smtp.gmail.com"),
  array("laxmantest2525@gmail.com",'Laxman@1231',587,"smtp.gmail.com"),
  array("metatest@metasyssoftware.com","1Kt@2021Mspl",587,"smtp.gmail.com"),   
  array("admissions.pbspune@gmail.com","PBS@2021",587,"smtp.gmail.com"),   
);
smtp_mailer1($myemailIds[0][0],$myemailIds[0][1],$myemailIds[0][2],$myemailIds[0][3]);
smtp_mailer1($myemailIds[1][0],$myemailIds[1][1],$myemailIds[1][2],$myemailIds[1][3]);

function smtp_mailer1($n,$p,$port,$host){
	$to='lkendre2525@gmail.com';
	$subject='testing';
	$msg='MSG';	

	$mail = new PHPMailer(); 
	$mail->SMTPDebug  = 3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = $host; // smtp change
	$mail->Port = $port; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = $n; // smtp email
	$mail->Password = $p; // pass
	$mail->SetFrom($n); // email
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){ ?>					
		<div class="alert alert-danger d-flex align-items-center" role="alert">
			<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
			<div><?php echo $mail->Username." Unable to send message please try again.<br>"; ?></div>
			</div>
		<?php
	}else{
		//echo 'Thanks your message has been sent now!';
		//header( "refresh:5;url=index.php" );
	}
}

?>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>




<?php
//include('smtp/PHPMailerAutoload.php');
// $msg_body= '';
// $username = $_POST['username'];
// $message = $_POST['message'];
// $options = $_POST['options'];
// $to_mail =  $_POST['email'];
// $msg_body .=  ' User Name : '.$username.'<br>';
// $msg_body .=  ' Message is : '.$message.'<br>';
// $msg_body .=  ' Option :'.$options.'<br>';
// $msg_body .=  ' Mail From: '. $to_mail;
// echo smtp_mailer($to_mail,'subject',$msg_body);
// function smtp_mailer($to,$subject, $msg){
// 	$mail = new PHPMailer(); 
// 	$mail->SMTPDebug  = 3;
// 	$mail->IsSMTP(); 
// 	$mail->SMTPAuth = true; 
// 	$mail->SMTPSecure = 'tls'; 
// 	$mail->Host = "smtp.gmail.com"; // smtp change
// 	$mail->Port = 587; 
// 	$mail->IsHTML(true);
// 	$mail->CharSet = 'UTF-8';
// 	$mail->Username = "ikftest33@gmail.com"; // smtp email
// 	$mail->Password = "ikf@123$$1"; // pass
// 	$mail->SetFrom("ikftest33@gmail.com"); // email
// 	$mail->Subject = $subject;
// 	$mail->Body =$msg;
// 	$mail->AddAddress($to);
// 	$mail->SMTPOptions=array('ssl'=>array(
// 		'verify_peer'=>false,
// 		'verify_peer_name'=>false,
// 		'allow_self_signed'=>false
// 	));
// 	if(!$mail->Send()){
// 		echo  $mail->Username;		
// 		echo "Unable to send message please try again.";
// 	}else{
// 		echo 'Thanks your message has been sent now!';
// 		header( "refresh:5;url=index.php" );
// 	}
// }
?>


<?php 

	// $cars = array (
	// 	array("Volvo",22,18),
	// 	array("BMW",15,13),
	// 	array("Saab",5,2),
	// 	array("Land Rover",17,15)
	//   );

	//   for($i=0;$i<count($cars);$i++){
	// 	 for($j=0;$j<$cars[$i]; $j++){
	// 		 echo $cars[$i][$j];

	// 	 } 

	//   }
?>


