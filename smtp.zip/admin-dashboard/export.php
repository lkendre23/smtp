<?php 

	$conn = mysqli_connect('localhost','ikfsmtp','l25kd89@#$xdfg','smtp_db')or die('unable to connect');
	
	$query = "SELECT * FROM `client_smtp`";

	$res = mysqli_query($conn, $query);
	$html = "<table><tr><th>#</th><th>WEBSITE</th><th>MAIL</th><th>PASSWORD</th><th>PORT</th><th>HOST</th></tr>";
	if( mysqli_num_rows($res) ){
	    while($rows  = mysqli_fetch_assoc($res) ){ 
	    	$html .= '<tr><td>'.$rows['ID'].'</td><td>'.$rows['website'].'</td><td>'.$rows['mailid'].'</td><td>'.$rows['pass'].'</td><td>'.$rows['port'].'</td><td>'.$rows['host'].'</td></tr>';

	    }
	    $html .= "</table>";
	}
	header("Content-Type:application/xls");
	header("Content-Disposition: attachment;filename=report.xls");
	echo $html; 

?>