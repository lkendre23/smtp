<?php 
/*
session_start();
$conn = mysqli_connect('localhost','ikfsmtp','l25kd89@#$xdfg','smtp_db')or die('unable to connect');
if(isset($_POST['submit'])){

	$username = $_POST['username'];
	$pass = $_POST['pass'];

	$query = "select * from login where username='$username' and password='$pass'  ";                            

	$result = mysqli_query($conn,$query);

    $myuser = '';

    if($rows = mysqli_num_rows($result) > 0 ){
        if($rows == 1){
        	$_SESSION['username'] = $username;
        	header('location:index.php');
        }else{
        	echo "failed";
        	header('location:login.php');
        }
    }


}


?>