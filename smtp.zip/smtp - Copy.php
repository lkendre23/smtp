<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>SMTP Testing</title>
  </head>
  <body>
  <?php
include('smtp/PHPMailerAutoload.php');
$myemailIds = array (
  array("ikftest33@gmail.com",'ikf@123$$1',587,"smtp.gmail.com"),
  array("laxmantest2525@gmail.com",'Laxman@123',587,"smtp.gmail.com"),
  array("metatest@metasyssoftware.com","1Kt@2021Mspl",587,"smtp.gmail.com"),   
  array("admissions.pbspune@gmail.com","PBS@2021",587,"smtp.gmail.com"), 
);
smtp_mailer1($myemailIds[0][0],$myemailIds[0][1],$myemailIds[0][2],$myemailIds[0][3]);
smtp_mailer1($myemailIds[1][0],$myemailIds[1][1],$myemailIds[1][2],$myemailIds[1][3]);
smtp_mailer1($myemailIds[2][0],$myemailIds[2][1],$myemailIds[2][2],$myemailIds[2][3]);
smtp_mailer1($myemailIds[3][0],$myemailIds[3][1],$myemailIds[3][2],$myemailIds[3][3]);

function smtp_mailer1($n,$p,$port,$host){
	$to='lkendre2525@gmail.com';
	$subject='testing';
	$msg='MSG';	

	$mail = new PHPMailer(); 
	$mail->SMTPDebug  = 3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = $host; // smtp change
	$mail->Port = $port; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = $n; // smtp email
	$mail->Password = $p; // pass
	$mail->SetFrom($n); // email
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){ ?>					
		<div class="alert alert-danger d-flex align-items-center" role="alert">
			<svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
			<div><?php echo $mail->Username." : Oops!, Something went wrong.<br>"; ?></div>
			</div>
		<?php
	}else{
		//echo 'Thanks your message has been sent now!';
		//header( "refresh:5;url=index.php" );
	}
}

?>

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  
  </body>
</html>



